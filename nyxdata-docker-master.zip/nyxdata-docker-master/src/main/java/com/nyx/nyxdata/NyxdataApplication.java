package com.nyx.nyxdata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NyxdataApplication {

	public static void main(String[] args) {
		SpringApplication.run(NyxdataApplication.class, args);
	}

}
